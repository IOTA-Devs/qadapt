# QAdapt self-healing framework
A web driver that uses self-healing to mitigate errors and sends reports of code running.
